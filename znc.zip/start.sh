#!/bin/ash
echo "⟳ Starting ZNC..."
znc -f -n -d /home/container/znc_data/
echo "✓ Successfully started"
