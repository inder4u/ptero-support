$(document).ready(function() {
	$('.swipebox').swipebox();
});