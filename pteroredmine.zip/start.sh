#!/bin/bash

plugin_install=0
plugin_remove=0

if [ $plugin_install == 1 ]; then cd /home/container/webroot/redmine/ && bundle exec rake redmine:plugins:migrate RAILS_ENV=production; fi
if [ $plugin_remove == 1 ]; then cd /home/container/webroot/redmine/ && bundle exec rake redmine:plugins NAME=redmine_work_time VERSION=1 RAILS_ENV=production; fi
if [ ! -f "/home/container/webroot/redmine/config/database.yml" ];
then 
	rm -rf /home/container/tmp/*
	cd /home/container/webroot/redmine/config
	cp database.yml.example database.yml
	cd /home/container/webroot/redmine/
	echo 'Add database info in database.yml in config directory and enter Y'
	read -p "" choice
	bundle install --without development test --path vendor/bundle
	bundle exec rake generate_secret_token
	RAILS_ENV=production bundle exec rake db:migrate
	RAILS_ENV=production REDMINE_LANG=en bundle exec rake redmine:load_default_data
fi
echo "⟳ Starting Nginx..."
echo "✓ Successfully started"
/opt/nginx/sbin/nginx -c /home/container/nginx/nginx.conf -p /home/container/